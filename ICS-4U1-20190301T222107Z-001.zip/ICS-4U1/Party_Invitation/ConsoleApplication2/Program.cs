﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {

        public static void setup()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
        }

        static void Main(string[] args)
        {
            //In our code I made it so that you can take a multiple out9 that is greater than number of decreases because it makes more sense
            //for the code because otherwise everytime the whole list would be cleared
            setup();
            List<int> namesList = new List<int>();

            Console.WriteLine("=============== Welcome to Party List ==============");
            Console.WriteLine();
        choofri:
            Console.WriteLine("=== Enter the number of friends you are inviting ===");
            Console.WriteLine();
            Console.WriteLine("===================== Max - 50 =====================");
            Console.WriteLine();

            int numfri = Convert.ToInt32(Console.ReadLine());
            if (1 > numfri)
            {
                Console.WriteLine("The number of friends was lower than 1, re-input");
                Console.WriteLine("Sorry if you have no friends");
                goto choofri;
            }

            if (50 <= numfri)
            {
                Console.WriteLine("The number of friends was higher than 50, re-input");
                goto choofri;

            }
            int realnumfri = numfri + 1;

            for (int i = 1; i < realnumfri; i++)
            {
                namesList.Add(i);
            }
            Console.WriteLine("# of Friends ");
            foreach (int p in namesList)
            {
                Console.WriteLine("Friend #" + p);
            }

        choomult:
            Console.WriteLine("Chose the # times you want to decrease your party list");
            Console.WriteLine("*The # of rounds must be smaller than 5 and greater than 0*");

            int input = Convert.ToInt32(Console.ReadLine());
            if (5 < input || 1 > input)
            {
                goto choomult;
            }

            Console.Clear();
            for (int i = 0; i < input; i++)
            {
            chooremove:
                Console.WriteLine("Enter the value of the multiples that you are removing");
                int n = Convert.ToInt32(Console.ReadLine());

                if (n == 1)
                {
                    Console.WriteLine("Are you sure you want to remove all multiples of 1 from the list, this will remove everyone.");
                    Console.WriteLine("Enter 1 to input a new multiple again, or input 2 to continue removing everyone");
                    int choice = Convert.ToInt32(Console.ReadLine());
                    if (choice == 1)
                    {
                        Console.WriteLine("You selected that you want to re-enter the value of the multiples you wish to remove");
                        goto chooremove;
                    }
                    if (choice == 2)
                    {
                        Console.Clear();
                        Console.WriteLine("You have removed everyone from your list");
                        Console.ReadLine();
                        Environment.Exit(0);


                    }
                }
                for (int remove = 0; remove < namesList.Count; remove++)
                {
                    if (namesList[remove] % n == 0)
                    {
                        Console.Clear();
                        namesList.RemoveAt(remove);

                    }

                }

                Console.WriteLine("");

                foreach (int d in namesList)
                {

                    Console.WriteLine(d);

                }
            }


            Console.Clear();
            Console.WriteLine("The final list has been chosen:");
            Console.WriteLine(" The friend list is:");

            foreach (int d in namesList)
            {

                Console.WriteLine("Friend #" + d);

            }

            Console.ReadLine();


        }
    }
}



